import os
import requests
from flask import Flask, render_template, request, jsonify
import geocoder

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

# Allow image files to be submitted
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze-skin')
def analyze_skin():
    return render_template('analyze-skin.html')

@app.route('/risk-profile')
def risk_profile():
    return render_template('risk-profile.html')

@app.route('/skin-type')
def skin_type():
    return render_template('skin-type.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    if file:
        main_py_url = "https://us-central1-skin-guard.cloudfunctions.net/predict"
        files = {'file': file}
        response = requests.post(main_py_url, files=files)
        
        if response.status_code == 200:
            data = response.json()
            return jsonify(data)
        else:
            return jsonify({'error': 'Failed to process the image'})
    else:
        return jsonify({'error': 'No selected file'})

# UV INDEX SECTION
mySession = requests.Session()


def get_user_location():
    try:
        # Get the client IP address
        user_ip = request.headers.get('X-Forwarded-For', request.remote_addr)

        # Replace 'IPSTACK_API_KEY' with your ipstack API key
        ipstack_api_key = os.environ.get('IPSTACK_API_KEY')
        
        if ipstack_api_key is None:
            return None  # Return None if API key is not set
        
        # Make a request to the ipstack API to get location data
        url = f"http://api.ipstack.com/{user_ip}?access_key={ipstack_api_key}"
        response = requests.get(url)
        data = response.json()

        # Extract relevant location information from the API response
        city = data.get('city')
        country_name = data.get('country_name')

        if city and country_name:
            return f"{city}, {country_name}", data  # Also return the location data
        else:
            return None, None
    except Exception as e:
        print(f"Error getting user location: {e}")
        return None, None



def get_lat_lon_from_location(location_data):
    latitude = location_data.get('latitude')
    longitude = location_data.get('longitude')
    return latitude, longitude


    
@app.route('/uv-index')
def uv_index():
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    location = request.args.get('location')

    # Check if latitude and longitude are provided
    if lat and lon:
        # Latitude and longitude provided, use them directly
        provided_location = None
    else:
        # Latitude and longitude not provided, try to get from user input
        provided_location, location_data = get_user_location()
        if provided_location:
            lat, lon = get_lat_lon_from_location(location_data)

    # If latitude and longitude are still not available, try geolocation
    if not lat or not lon:
        user_location, location_data = get_user_location()
        if user_location:
            # Attempt to get latitude and longitude from location data
            lat, lon = get_lat_lon_from_location(location_data)
            provided_location = None
        else:
            # Handle case where user_location is None
            return jsonify({'error': 'User location could not be determined'})



    if lat and lon:
        uv_index_data = get_uv_index(lat, lon)
        if 'error' in uv_index_data:
            return jsonify({'error': 'Failed to fetch UV index data'})
        return render_template('uv-index.html', uv_index_data=uv_index_data, location=provided_location or "Unknown Location")
    else:
        return jsonify({'error': 'Latitude and longitude could not be determined'})


    
# Function to get UV index
def get_uv_index(lat, lon):
    try:
        OPENUV_API_KEY = os.environ.get('OPENUV_API_KEY')  # Retrieve API key from environment variables
        headers = {'x-access-token': OPENUV_API_KEY}
        url = f"https://api.openuv.io/api/v1/uv?lat={lat}&lng={lon}"
        
        # Use session object to make the request
        response = mySession.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()

        current_uv_index = int(data.get('result', {}).get('uv') or 0)
        uv_max = int(data.get('result', {}).get('uv_max') or 0)
        location = data.get('result', {}).get('location', {}).get('name')

        return {
            'current_uv_index': current_uv_index,
            'uv_max': uv_max,
            'location': location
        }
    except Exception as e:
        print(f"Error fetching UV index data: {e}")
        return {'error': 'Failed to fetch UV index data'}

@app.route('/user-location')
def user_location():
    location = get_user_location()
    if location:
        return f"User's location: {location}"
    else:
        return "Unable to determine user's location"
    
if __name__ == '__main__':
    # Get the port from the environment variable or use a default value
    port = int(os.environ.get('PORT', 5000))
    # Start the Flask app
    app.run(host='0.0.0.0', port=port)
