import os
import tempfile
from flask import jsonify, request
from google.cloud import storage
import numpy as np
from tensorflow.keras.preprocessing import image
import tensorflow as tf

BUCKET_NAME = "skin-guard"  # Update with your bucket name

def download_blob(bucket_name, source_blob_name, destination_file_name):
    """Downloads a blob from the bucket."""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(source_blob_name)
    blob.download_to_filename(destination_file_name)

def predict_image(file_path, model_path):
    # Load the model
    model = tf.keras.models.load_model(model_path, compile=False)
    
    # Resize image file
    img = image.load_img(file_path, target_size=(224, 224))
    # Convert the file into an array of values
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.0  # And normalize the image
    
    prediction = model.predict(img_array) # Predict the array-converted image using the deployed model
    prediction_score = prediction[0][0]  # Get prediction score in a form of binary classification
    
    # Malignant and benign classifications
    if prediction_score > 0.5:
        result = "Malignant"
    else:
        result = "Benign" # Results ranges from 0.49 to less than 0.01
    
    return result, float(prediction_score)  # Ensure prediction_score is a float type

def predict(request):
    return upload_and_predict(request)

def upload_and_predict(request):
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'})
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No selected file'})
        if file:
            # Save the file temporarily
            _, temp_local_filename = tempfile.mkstemp()
            file.save(temp_local_filename)
            
            # Download the model file from the models folder
            temp_local_model_file = os.path.join(tempfile.gettempdir(), "model.h5")
            download_blob(BUCKET_NAME, "models/model.h5", temp_local_model_file)
            
            # Perform prediction
            result, scaled_value = predict_image(temp_local_filename, temp_local_model_file)

            # Print the results for debugging
            print("Prediction Result:", result)
            print("Scaled Value:", scaled_value)

            # Remove the temporary files
            os.remove(temp_local_filename)
            os.remove(temp_local_model_file)
            
            return jsonify({'result': result, 'scaled_value': scaled_value})
    else:
        return jsonify({'error': 'Invalid request method'})
